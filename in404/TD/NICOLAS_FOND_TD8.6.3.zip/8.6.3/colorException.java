public class colorException extends Exception {
  public colorException() {
    super();
  }
}
