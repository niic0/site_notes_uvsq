#include "arbre_token.h"

void structure (ARBRE* root, int level );
void print_token (TOKEN *T);
void print_tokens (LISTE_TOKEN liste);
void usage();
